/*
 * main.cpp
 *
 *  Created on: Feb 19, 2021
 *      Author: zhaoyi82
 */

#define switches (volatile short *) 0x00009000
#define leds (volatile short *) 0x00009010

int main()
{
  while (1)
    *leds = *switches;
}
